# Joshinkan Dojo, Astro scaffold

A three-page Astro site for the Center for Aikido Study, wired to the Sumi theme by default with Kaze and Yoru CSS ready to swap.

## Stack

- Astro 5, static output, zero JS by default
- TypeScript, strict
- Plain CSS with CSS variables for theming, no Tailwind
- `@astrojs/sitemap` for sitemap generation
- Content collections, instructors as markdown files

## Pages

1. `/` Home: hero, what we practice, schedule preview, CTA
2. `/about/` About: dojo story, what Aikido is, instructors (rendered from content collection), lineage
3. `/visit/` Visit: full schedule, membership paths, dues, location, contact

## Get started

```sh
npm install
npm run dev      # http://localhost:4321
npm run build    # static output in dist/
npm run preview  # serve the built site
```

Node 20 or later. macOS friendly.

## File layout

```
src/
  data/site.ts                 single source of truth for SITE, CONTACT, SCHEDULE, DUES, NAV, LINKS
  content/instructors/         markdown files, one per instructor
  content.config.ts            content collection schema (Astro 5 glob loader)
  layouts/BaseLayout.astro     page shell with header, footer, meta tags
  components/
    Header.astro               brand and nav, highlights current page via .is-current
    Footer.astro               four-section footer with copyright row
    Schedule.astro             renders SCHEDULE from site.ts as .schedule / .schedule-row
    InstructorList.astro       renders instructors collection as .instructors / .instructor
  pages/
    index.astro                Home
    about.astro                About
    visit.astro                Visit
  styles/
    global.css                 active theme (Sumi by default)
    theme-kaze.css             Kaze theme (warm modern editorial)
    theme-yoru.css             Yoru theme (refined dark)
```

## Theme swap, the honest version

Each of the three variants in the parent `variant-*` folders has its own header and footer markup, not just different CSS. The Sumi header is a simple two part flex; Kaze and Yoru each restructure the chrome differently.

This scaffold ships with the Sumi markup wired up. To switch to Kaze or Yoru:

1. Replace `src/styles/global.css` contents with the corresponding theme file:
   ```sh
   cp src/styles/theme-kaze.css src/styles/global.css
   # or
   cp src/styles/theme-yoru.css src/styles/global.css
   ```
2. Update `src/components/Header.astro` and `src/components/Footer.astro` to match the chosen variant's markup. Copy structurally from `../variant-2-kaze/index.html` or `../variant-3-yoru/index.html` and keep the existing dynamic nav loop in `Header.astro`.

A future improvement is to extract per-theme `Header.*.astro` and `Footer.*.astro` components and a single THEME constant that switches them. Left out of this scaffold so the starting point stays small and obvious.

## Editing dojo data

All schedule, contact, dues, and navigation values live in `src/data/site.ts`. Edit there, not in templates. Instructor bios live in `src/content/instructors/*.md`.

## Mobile nav, not yet implemented

Responsive CSS is in place but there is no hamburger menu yet. Easiest path: a small `MobileNav.astro` island with `client:load`, toggling a class on `body`. Worth adding before launch.

## Deploy

Any static host. Builds clean to `dist/`. Recommended:

- Netlify or Cloudflare Pages, drag and drop or git connect
- `astro.config.mjs` already sets `site: 'https://www.raleighaikido.com'` for canonical URLs and sitemap

## Still placeholder

- Instructor portraits (the InstructorList renders text only)
- Dojo interior photography
- Map embed (replace `.map-block` placeholder with a Google Maps iframe or styled Leaflet block)
- JSON-LD `MartialArtsSchool` schema (worth adding to BaseLayout before launch)

Drop real assets into `public/` and reference them from the templates.
