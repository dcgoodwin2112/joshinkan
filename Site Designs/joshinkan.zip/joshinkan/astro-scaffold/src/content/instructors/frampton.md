---
name: Sensei Dave Frampton
rank: Yondan
rankNote: 4th degree black belt
role: Instructor
teaches: Wednesday
order: 2
---

Frampton Sensei teaches Wednesday evenings. His classes emphasize the basic principles and their applications across the dojo's curriculum.
